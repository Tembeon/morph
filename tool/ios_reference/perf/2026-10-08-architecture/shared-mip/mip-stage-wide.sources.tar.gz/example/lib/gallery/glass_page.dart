import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';

import 'package:material_ui/material_ui.dart';
import 'package:morph/widgets.dart';
import 'package:morph_example/gallery/gallery.dart';
import 'package:morph_example/gallery/glass_settings.dart';

/// The gallery's glass settings and a sample of every control over a
/// colorful backdrop.
///
/// The settings belong to the whole gallery: the glass tier, its material
/// and optics, the appearance, the text direction and the disabled demo
/// controls apply to every page at once, and last for the session.
class GlassPage extends StatefulWidget {
  /// Creates the page.
  const GlassPage({super.key});

  @override
  State<GlassPage> createState() => _GlassPageState();
}

class _GlassPageState extends State<GlassPage> {
  int _segment = 0;
  int _tab = 0;
  bool _toggle = true;
  double _value = 0.4;
  double _count = 3;
  int _page = 1;

  static const _tiers = ['Auto', 'Liquid', 'Fake', 'Flat'];
  static const _materials = ['Regular', 'Toolbar', 'Clear'];

  /// The iOS Settings > Display & Brightness > Liquid Glass choice; the
  /// knob below sets any position between the two.
  static const _liquidGlass = ['Clear', 'Tinted'];
  static const _appearances = ['System', 'Light', 'Dark'];

  Widget _scene(BuildContext context) {
    T? on<T extends Function>(T callback) =>
        GalleryGlassScope.enabled(context, callback);
    final enabled = !GalleryGlassScope.of(context).disabled;
    return Padding(
      padding: const .fromLTRB(20, 24, 20, 28),
      child: Column(
        children: [
          MorphSegmentedControl(
            segments: const ['Photos', 'Albums', 'Search'],
            selected: _segment,
            onChanged: on((int i) => setState(() => _segment = i)),
          ),
          const SizedBox(height: 28),
          Row(
            children: [
              MorphSwitch(
                value: _toggle,
                semanticLabel: 'Sample switch',
                onChanged: on((bool v) => setState(() => _toggle = v)),
              ),
              const Spacer(),
              MorphStepper(
                value: _count,
                max: 9,
                onChanged: on((double v) => setState(() => _count = v)),
              ),
            ],
          ),
          const SizedBox(height: 28),
          MorphSlider(
            value: _value,
            semanticLabel: 'Sample slider',
            onChanged: on((double v) => setState(() => _value = v)),
          ),
          const SizedBox(height: 28),
          MorphGlassContainer(
            child: Wrap(
              alignment: .center,
              spacing: 16,
              runSpacing: 12,
              children: [
                MorphGlassButton(
                  onPressed: on(() {}),
                  child: const Text('Glass'),
                ),
                MorphGlassButton(
                  onPressed: on(() {}),
                  tint: const Color(0xFF0088FF),
                  child: const Text('Prominent'),
                ),
                MorphGlassButton(
                  onPressed: on(() {}),
                  child: const Icon(Icons.favorite_border),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: .center,
            children: [
              MorphMenuButton(
                enabled: enabled,
                items: const [
                  MorphMenuItem(title: 'Copy', icon: Icons.copy),
                  MorphMenuItem(title: 'Share', icon: Icons.ios_share),
                ],
              ),
              const SizedBox(width: 24),
              MorphPageControl(
                count: 5,
                page: _page,
                onChanged: on((int i) => setState(() => _page = i)),
              ),
            ],
          ),
          const SizedBox(height: 20),
          MorphSearchField(enabled: enabled),
          const SizedBox(height: 36),
          MorphTabBar(
            items: const [
              MorphTabItem(icon: Icons.photo_outlined, label: 'Library'),
              MorphTabItem(icon: Icons.favorite_border, label: 'For You'),
              MorphTabItem(icon: Icons.search, label: 'Search'),
            ],
            selected: _tab,
            onChanged: on((int i) => setState(() => _tab = i)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = GalleryGlassScope.of(context);
    final dark = Theme.of(context).brightness == Brightness.dark;
    final drawn = MorphAdaptiveGlass.tierOf(context);
    final liquid = drawn == MorphGlassTier.liquid;
    return GalleryPage(
      title: 'Glass renderer',
      slivers: [
        SliverToBoxAdapter(
          child: BackdropGroup(
            child: Stack(
              children: [
                Positioned.fill(child: _Backdrop(dark: dark)),
                DefaultTextStyle.merge(
                  style: TextStyle(color: dark ? Colors.white : Colors.black),
                  child: _scene(context),
                ),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: BackdropGroup(
            child: MorphListSection(
              header: 'Renderer',
              children: [
                _Choice(
                  label: 'Tier',
                  segments: _tiers,
                  selected: switch (settings.tier) {
                    null => 0,
                    MorphGlassTier.liquid => 1,
                    MorphGlassTier.fake => 2,
                    MorphGlassTier.flat => 3,
                  },
                  onChanged: (int i) => settings.tier = switch (i) {
                    1 => MorphGlassTier.liquid,
                    2 => MorphGlassTier.fake,
                    3 => MorphGlassTier.flat,
                    _ => null,
                  },
                ),
                MorphListRow(
                  title: const Text('Drawing'),
                  detail: Text(drawn?.name ?? 'none'),
                ),
                _Choice(
                  label: 'Material',
                  segments: _materials,
                  selected: settings.material.index,
                  onChanged: liquid
                      ? (int i) =>
                            settings.material = MorphGlassMaterial.values[i]
                      : null,
                ),
                _Knob(
                  label: 'Blur',
                  value: settings.blur,
                  max: 3,
                  onChanged: liquid ? (double v) => settings.blur = v : null,
                ),
                _Knob(
                  label: 'Refraction',
                  value: settings.refraction,
                  max: 2,
                  onChanged: liquid
                      ? (double v) => settings.refraction = v
                      : null,
                ),
                _Knob(
                  label: 'Rim light',
                  value: settings.light,
                  max: 2,
                  onChanged: liquid ? (double v) => settings.light = v : null,
                ),
                _Choice(
                  label: 'Liquid Glass',
                  segments: _liquidGlass,
                  selected: settings.tint < 0.5 ? 0 : 1,
                  onChanged: liquid
                      ? (int i) => settings.tint = i.toDouble()
                      : null,
                ),
                _Knob(
                  label: 'Clear to tinted',
                  value: settings.tint,
                  max: 1,
                  onChanged: liquid ? (double v) => settings.tint = v : null,
                ),
                _Toggle(
                  label: 'Frost controls',
                  value: settings.frostControls,
                  onChanged: liquid
                      ? (bool v) => settings.frostControls = v
                      : null,
                ),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: BackdropGroup(
            child: MorphListSection(
              header: 'Gallery',
              footer:
                  'These settings apply to every page of the gallery. The '
                  'glass inspector counts the glass layers of each frame '
                  'and names neighbouring resting glass that one '
                  'MorphGlassContainer could shade together.',
              children: [
                _Choice(
                  label: 'Appearance',
                  segments: _appearances,
                  selected: settings.appearance.index,
                  onChanged: (int i) =>
                      settings.appearance = ThemeMode.values[i],
                ),
                _Toggle(
                  label: 'Right to left',
                  value: settings.rtl,
                  onChanged: (bool v) => settings.rtl = v,
                ),
                _Toggle(
                  label: 'Disabled',
                  value: settings.disabled,
                  onChanged: (bool v) => settings.disabled = v,
                ),
                if (!kReleaseMode)
                  _Toggle(
                    label: 'Glass inspector',
                    value: settings.inspector,
                    onChanged: (bool v) => settings.inspector = v,
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _Choice extends StatelessWidget {
  const _Choice({
    required this.label,
    required this.segments,
    required this.selected,
    required this.onChanged,
  });

  final String label;
  final List<String> segments;
  final int selected;
  final ValueChanged<int>? onChanged;

  @override
  Widget build(BuildContext context) {
    return MorphListRow(
      child: Row(
        children: [
          SizedBox(width: 96, child: Text(label)),
          Expanded(
            child: MorphSegmentedControl(
              segments: segments,
              selected: selected,
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }
}

class _Knob extends StatelessWidget {
  const _Knob({
    required this.label,
    required this.value,
    required this.max,
    required this.onChanged,
  });

  final String label;
  final double value;
  final double max;
  final ValueChanged<double>? onChanged;

  @override
  Widget build(BuildContext context) {
    final onChanged = this.onChanged;
    return MorphListRow(
      child: Row(
        children: [
          SizedBox(width: 96, child: Text(label)),
          Expanded(
            child: MorphSlider(
              value: value / max,
              semanticLabel: label,
              onChanged: onChanged == null
                  ? null
                  : (double v) => onChanged(v * max),
            ),
          ),
          SizedBox(
            width: 48,
            child: Text(
              value.toStringAsFixed(2),
              textAlign: .end,
              style: const TextStyle(
                fontFeatures: [ui.FontFeature.tabularFigures()],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Toggle extends StatelessWidget {
  const _Toggle({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final bool value;
  final ValueChanged<bool>? onChanged;

  @override
  Widget build(BuildContext context) {
    return MorphListRow(
      title: Text(label),
      trailing: MorphSwitch(
        value: value,
        semanticLabel: label,
        onChanged: onChanged,
      ),
    );
  }
}

class _Backdrop extends StatelessWidget {
  const _Backdrop({required this.dark});

  final bool dark;

  @override
  Widget build(BuildContext context) {
    const blobs = <(Alignment, double, Color)>[
      (Alignment(-0.9, -0.8), 180, Color(0xFFFF2D55)),
      (Alignment(0.8, -0.4), 220, Color(0xFFFFCC00)),
      (Alignment(-0.5, 0.3), 200, Color(0xFF34C759)),
      (Alignment(0.7, 0.8), 240, Color(0xFF5856D6)),
    ];
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: .topLeft,
          end: .bottomRight,
          colors: dark
              ? const [Color(0xFF0B1E3D), Color(0xFF2B0B3D)]
              : const [Color(0xFF8EC5FC), Color(0xFFE0C3FC)],
        ),
      ),
      child: Stack(
        children: [
          for (final (alignment, size, color) in blobs)
            Align(
              alignment: alignment,
              child: Container(
                width: size,
                height: size,
                decoration: BoxDecoration(
                  shape: .circle,
                  color: color.withValues(alpha: dark ? 0.55 : 0.8),
                ),
              ),
            ),
          const Align(
            alignment: Alignment(0, -0.1),
            child: Text(
              'morph',
              style: TextStyle(
                fontSize: 96,
                fontWeight: .w900,
                color: Color(0x66FFFFFF),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
