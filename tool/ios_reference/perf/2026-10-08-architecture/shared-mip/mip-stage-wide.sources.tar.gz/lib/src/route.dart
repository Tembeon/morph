import 'package:material_ui/material_ui.dart';
import 'package:flutter/services.dart' show PredictiveBackEvent;

import 'package:morph/src/controller.dart';
import 'package:morph/src/flight.dart';
import 'package:morph/src/gesture.dart';
import 'package:morph/src/measure.dart';
import 'package:morph/src/scope.dart';
import 'package:morph/src/scrim.dart';
import 'package:morph/src/motion.dart';
import 'package:morph/src/target.dart';
import 'package:morph/src/theme.dart';

/// A real Navigator route whose visual transition is a morph flight.
///
/// The route is pushed IMMEDIATELY, so the Navigator owns the truth
/// from the first frame: back button, predictive back, deep links and
/// further pushes all behave normally. The flight plays in the overlay
/// while the route page stays empty; once the open spring settles, the
/// second latch fires - ownership of the target content transfers from
/// the shuttle to the route page. Both sides rebuild in the same frame
/// and the content subtree carries a shared [GlobalKey], so it
/// reparents with its live state (scroll positions, text fields,
/// counters survive). A pop hands the content back to the shuttle the
/// same way and plays the ordinary close flight; a close launched from
/// the flight side (a button calling flight.close) retires the route
/// automatically.
///
/// The scrim swaps between the two owners at full opacity on both
/// latches, so the handovers are invisible.
/// [from] may be omitted when called inside the source tag's subtree,
/// mirroring [showMorph].
///
/// The route pushes into the NEAREST enclosing navigator: a page
/// belongs to the navigator that owns its context, so a morph route
/// launched inside a nested navigator (a tab, an embedded flow) stays
/// there. Pass [useRootNavigator] to push above everything instead.
/// [overlay] chooses the shuttle's home independently; a different overlay
/// retains the content in the shuttle for the route lifetime.
/// [scrimMotion] resolves from [MorphTheme] when omitted.
/// Set [modal] to false to keep the page underneath interactive without
/// a scrim or modal barrier. Back still dismisses the route; Escape follows
/// [barrierDismissible].
/// The source scope is resolved from [context], including scopes inside
/// a navigator's page.
Future<T?> showMorphRoute<T>(
  BuildContext context, {
  Object? from,
  required MorphContentBuilder builder,
  MorphTargetSpec? target,
  MorphMotion? motion,
  bool barrierDismissible = true,
  bool modal = true,
  bool useRootNavigator = false,
  double? maxScrimOpacity,
  Color? scrimColor,
  MorphScrimMotion? scrimMotion,
  OverlayState? overlay,
  Color? shadowColor,
  String? semanticLabel,
}) {
  final Object source = from ?? MorphTag.idOf(context);
  MorphFlight.checkRouteLaunch(MorphScope.of(context).liveFlightOf(source));
  final MorphTheme? theme = MorphTheme.maybeOf(context);
  return Navigator.of(context, rootNavigator: useRootNavigator).push(
    MorphPageRoute<T>(
      from: source,
      builder: builder,
      target: target ?? MorphTargetSpec.dialog(),
      motion: motion ?? theme?.motion,
      barrierDismissible: barrierDismissible,
      modal: modal,
      sourceContext: context,
      barrierLabel: Localizations.of<MaterialLocalizations>(
        context,
        MaterialLocalizations,
      )?.modalBarrierDismissLabel,
      maxScrimOpacity:
          maxScrimOpacity ??
          theme?.maxScrimOpacity ??
          MorphTheme.defaultMaxScrimOpacity,
      scrimColor:
          scrimColor ?? theme?.scrimColor ?? MorphTheme.defaultScrimColor,
      scrimMotion: scrimMotion ?? theme?.scrimMotion,
      overlay: overlay,
      shadowColor:
          shadowColor ?? theme?.shadowColor ?? MorphTheme.defaultShadowColor,
      semanticLabel: semanticLabel,
    ),
  );
}

/// The route half of [showMorphRoute]; usable directly with
/// Navigator.push for named-route setups.
///
/// Predictive back (Android): the route claims the system back gesture
/// and scrubs the flight itself - the card visibly starts its journey
/// home under the finger (a short, shallow scrub: value 1 down to
/// 1 - [_predictiveBackDepth], too small for the fade-through
/// midstates to read). The content returns to the shuttle for the
/// whole gesture; a cancel springs back to settled and the second
/// latch re-hands the content to the page, a commit pops and the
/// ordinary close plays from the scrubbed value.
class MorphPageRoute<T> extends PopupRoute<T> {
  /// Creates the route; prefer [showMorphRoute], which also resolves
  /// [MorphTheme] defaults and the localized barrier label.
  MorphPageRoute({
    required this.from,
    required this.builder,
    required this.target,
    this.motion,
    this.modal = true,
    this.sourceContext,
    // Private named parameters (callers pass the public names) backing
    // the ModalRoute getter overrides.
    this._barrierDismissible = true,
    this._barrierLabel,
    this.maxScrimOpacity = MorphTheme.defaultMaxScrimOpacity,
    this.scrimColor = MorphTheme.defaultScrimColor,
    this.scrimMotion,
    this.overlay,
    this.shadowColor = MorphTheme.defaultShadowColor,
    this.semanticLabel,
    super.settings,
  });

  /// The source tag id; the tag must be mounted when the route is
  /// pushed.
  final Object from;

  /// Builds the page content (lives in the shuttle until the second
  /// latch).
  final MorphContentBuilder builder;

  /// The destination description.
  final MorphTargetSpec target;

  /// Motion profile; this constructor does not consult [MorphTheme].
  final MorphMotion? motion;

  /// Whether the route blocks input to the page underneath and draws a
  /// scrim. False omits both the shuttle scrim and the route's modal barrier.
  /// Escape dismissal still follows [barrierDismissible].
  final bool modal;

  /// A mounted context under the source tag's [MorphScope].
  ///
  /// [showMorphRoute] supplies its launching context. Direct pushes may
  /// omit it when the scope sits above the navigator; otherwise pass a
  /// context inside the page's scope. Used only when the route is pushed.
  final BuildContext? sourceContext;

  /// Scrim opacity in the settled state.
  final double maxScrimOpacity;

  /// Scrim hue; its own opacity composes with the animated scrim
  /// opacity. This constructor does not consult [MorphTheme].
  final Color scrimColor;

  /// The scrim's independent springs, or null to follow the flight value.
  /// This constructor does not consult [MorphTheme].
  final MorphScrimMotion? scrimMotion;

  /// The shuttle's overlay; null uses this route's navigator overlay.
  ///
  /// With a different overlay, the shuttle retains the content for the
  /// route lifetime, preserving that overlay's coordinates and stacking.
  final OverlayState? overlay;

  /// Shadow color of the flying surface and the settled page, opacity
  /// included. This constructor does not consult [MorphTheme].
  final Color shadowColor;

  /// Accessibility name of the route (screen readers announce it).
  final String? semanticLabel;
  final bool _barrierDismissible;
  final String? _barrierLabel;

  MorphFlight? _flight;

  /// The live flight of this route; null before didPush.
  MorphFlight? get flight => _flight;

  // The flight and the route page own all scrim painting; the modal
  // barrier stays transparent and only contributes dismiss semantics
  // and taps once the route owns the content.
  @override
  Color? get barrierColor => null;

  @override
  bool get barrierDismissible => _barrierDismissible;

  // The accessibility label of the DISMISS affordance, not the route's
  // name (that is [semanticLabel]): showMorphRoute passes the localized
  // modal-barrier label.
  @override
  String? get barrierLabel => _barrierLabel;

  // The spring animates the visuals; the route machinery is instant.
  @override
  Duration get transitionDuration => .zero;

  @override
  Widget buildModalBarrier() =>
      modal ? super.buildModalBarrier() : const SizedBox.shrink();

  // How deep the predictive-back preview scrubs the value at full
  // gesture progress: enough for the card to visibly shrink toward its
  // source, not enough for the content crossfade to expose midstates.
  static const double _predictiveBackDepth = 0.18;

  bool _predictiveBack = false;
  double _predictiveBackFrom = 1;
  late final _RouteBackGestureObserver _backObserver =
      _RouteBackGestureObserver(this);

  // The PredictiveBackRoute hooks, reimplemented on the flight: the
  // default TransitionRoute behavior drives the route's own transition
  // controller, which is a zero-duration shell here - the morph spring
  // is the transition.

  @override
  void handleStartBackGesture({double progress = 0.0}) {
    final MorphFlight? flight = _flight;
    // With an overlay flight stacked above (a local history entry) the
    // back gesture pops that flight, not this route: decline the scrub.
    if (!isCurrent ||
        willHandlePopInternally ||
        flight == null ||
        flight.isFinished) {
      return;
    }
    _predictiveBack = true;
    // The scrub plays in the shuttle: the content comes back for the
    // whole gesture, whichever way it ends.
    flight.routeOwnsContent.value = false;
    flight.refreshSourceRect();
    flight.controller.beginScrub();
    _predictiveBackFrom = flight.controller.value;
    handleUpdateBackGestureProgress(progress: progress);
  }

  @override
  void handleUpdateBackGestureProgress({required double progress}) {
    if (!_predictiveBack) {
      return;
    }
    final double value = _predictiveBackFrom - _predictiveBackDepth * progress;
    _flight?.controller.updateScrub(value < 0 ? 0 : value);
  }

  @override
  void handleCommitBackGesture() {
    if (!_predictiveBack) {
      return;
    }
    _predictiveBack = false;
    if (isCurrent) {
      // didPop plays the close from the scrubbed value.
      navigator?.pop();
    } else {
      _flight?.close();
    }
  }

  @override
  void handleCancelBackGesture() {
    if (!_predictiveBack) {
      return;
    }
    _predictiveBack = false;
    // Spring back to settled; the second latch re-hands the content to
    // the page on its own.
    _flight?.open();
  }

  @override
  TickerFuture didPush() {
    final NavigatorState nav = navigator!;
    final MorphFlight flight = .launch(
      sourceContext ?? nav.context,
      from: from,
      target: target,
      builder: builder,
      motion: motion,
      modal: modal,
      barrierDismissible: _barrierDismissible,
      maxScrimOpacity: maxScrimOpacity,
      scrimColor: scrimColor,
      scrimMotion: scrimMotion,
      shadowColor: shadowColor,
      semanticLabel: semanticLabel,
      routeMode: true,
      overlay: overlay ?? nav.overlay,
      // Pre-latch the scrim belongs to the shuttle: its dismiss taps
      // route through the Navigator so the route lifecycle stays the
      // single source of truth.
      onDismissRequested: _handleDismissRequest,
    );
    _flight = flight;
    WidgetsBinding.instance.addObserver(_backObserver);
    flight.controller.addListener(_onFlightTick);
    flight.closed.then((Object? _) {
      if (isActive) {
        navigator?.removeRoute(this);
      }
    });
    return super.didPush();
  }

  void _handleDismissRequest() {
    if (isCurrent) {
      navigator?.pop();
    }
  }

  void _onFlightTick() {
    final MorphFlight? flight = _flight;
    if (flight == null) {
      return;
    }
    final MorphController c = flight.controller;
    if (flight.isFinished) {
      c.removeListener(_onFlightTick);
      if (isActive) {
        navigator?.removeRoute(this);
      }
      return;
    }
    if (!flight.routeOwnsContent.value) {
      _syncSecondLatch();
    } else if (c.target == 0) {
      // A close launched from the flight side (a button calling
      // flight.close): hand the content back for the landing and retire
      // the route without replaying the close.
      flight.routeOwnsContent.value = false;
      if (isActive) {
        navigator?.removeRoute(this);
      }
    }
  }

  /// The second latch: the open spring has settled and this route is
  /// still in the stack - the page adopts the content. isActive, not
  /// isCurrent: settling UNDER a covering route must still hand the
  /// content to the page, otherwise the shuttle (the topmost overlay
  /// entry, scrim included) stays parked above the covering route and
  /// swallows its input - and with the spring settled there are no
  /// more ticks to retry on.
  void _syncSecondLatch() {
    final MorphFlight? flight = _flight;
    if (flight == null || flight.isFinished || flight.routeOwnsContent.value) {
      return;
    }
    final MorphController c = flight.controller;
    if (overlay != null && overlay != navigator?.overlay) {
      return;
    }
    if (c.target >= 1 && !c.isAnimating && !c.isScrubbing && isActive) {
      flight.routeOwnsContent.value = true;
    }
  }

  // The latch condition also moves when the ROUTE moves while the
  // spring stands still (a cover pushed over a settling route, a
  // cover popped away): re-evaluate on the route lifecycle, not only
  // on controller ticks.
  @override
  void didChangeNext(Route<Object?>? nextRoute) {
    super.didChangeNext(nextRoute);
    _syncSecondLatch();
  }

  @override
  void didPopNext(Route<Object?> nextRoute) {
    super.didPopNext(nextRoute);
    _syncSecondLatch();
  }

  @override
  bool didPop(T? result) {
    if (willHandlePopInternally) {
      // A LocalHistoryEntry sits on top of this route - an overlay
      // flight (a menu, a popover) opened above the page. The pop
      // belongs to IT, not to this route's flight.
      return super.didPop(result);
    }
    _predictiveBack = false;
    final MorphFlight? flight = _flight;
    if (flight != null && !flight.isFinished) {
      // Hand the content back to the shuttle in the same frame the page
      // goes away, then play the ordinary close. close() is a no-op if
      // the flight is already closing. The pop result rides the
      // flight's own closed future too, so both calling conventions
      // agree.
      flight.routeOwnsContent.value = false;
      flight.close(result: result);
    }
    return super.didPop(result);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(_backObserver);
    final MorphFlight? flight = _flight;
    flight?.controller.removeListener(_onFlightTick);
    if (flight != null && !flight.isFinished) {
      flight.routeOwnsContent.value = false;
      if (flight.tag.mounted) {
        flight.close();
      } else {
        flight.abort();
      }
    }
    super.dispose();
  }

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    return _MorphRoutePage<T>(route: this);
  }
}

/// The settled state of the flight, replicated as a plain page: the
/// same scrim, the same surface, the same content chain - so the
/// shuttle-to-route swap is pixel-identical.
class _MorphRoutePage<T> extends StatefulWidget {
  const _MorphRoutePage({required this.route});

  final MorphPageRoute<T> route;

  @override
  State<_MorphRoutePage<T>> createState() => _MorphRoutePageState<T>();
}

class _MorphRoutePageState<T> extends State<_MorphRoutePage<T>> {
  // The route-side anchor for SharedSideScope: shared elements only
  // measure mid-flight (shuttle-owned), but the wrapper chain must
  // match the shuttle's exactly for the reparent to preserve state.
  final GlobalKey _anchorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    final MorphFlight? flight = widget.route._flight;
    if (flight == null) {
      return const SizedBox.shrink();
    }
    return ListenableBuilder(
      listenable: flight.sourceThemes,
      builder: (BuildContext context, Widget? _) => flight.sourceThemes.wrap(
        Builder(
          builder: (BuildContext context) => _buildThemed(context, flight),
        ),
      ),
    );
  }

  Widget _buildThemed(BuildContext context, MorphFlight flight) {
    return ListenableBuilder(
      listenable: flight.routeOwnsContent,
      builder: (BuildContext context, Widget? _) {
        if (!flight.routeOwnsContent.value) {
          return const SizedBox.shrink();
        }
        final MorphSurfaceSpec spec = resolveMorphTargetSurface(
          flight,
          Theme.of(context).colorScheme,
        );
        return LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            final Size overlaySize = constraints.biggest;
            // The same space the shuttle places the target in: the
            // safe area unioned with the keyboard.
            final EdgeInsets padding = morphTargetPaddingOf(
              context,
              overlaySize,
              overlayBox: flight.overlayBox,
            );
            final MediaQueryData mediaQuery = MediaQuery.of(context);
            final EdgeInsets overlayViewInsets = morphOverlayViewInsetsOf(
              context,
              overlaySize,
              overlayBox: flight.overlayBox,
            );
            final MorphTargetSpec target = flight.target;
            // The SAME chain the shuttle mounts, from the one shared
            // builder: the route-mode reparent preserves state only
            // while the chains match, and now they cannot drift. A
            // measured target keeps measuring on the settled page, so
            // a live size change springs here exactly as in the
            // shuttle.
            final Widget content = buildMorphTargetContent(
              flight: flight,
              spec: spec,
              anchorKey: _anchorKey,
            );
            final BoxConstraints Function(Size, EdgeInsets)? constraintsFor =
                target.constraintsFor;
            final Widget measured = constraintsFor == null
                ? content
                : MorphContentMeasure(
                    childConstraints: constraintsFor(overlaySize, padding),
                    alignment: target.contentAlignment,
                    onSize: flight.reportContentSize,
                    child: content,
                  );
            // The displacement channel works on the settled page too:
            // the same rigid-body shift, recede and scrim math the
            // shuttle applies, driven by the same frame stream - a
            // drag feels identical on both sides of the second latch.
            return ListenableBuilder(
              listenable: flight.frameTicks,
              builder: (BuildContext context, Widget? child) {
                final Rect rect = target.resolveRect(
                  overlaySize,
                  padding,
                  flight.contentSize,
                );
                // Keep the flight's belief fresh while the route owns
                // the layout: a pop closes FROM this rect.
                flight.updateTargetRect(rect);
                final Offset drag = flight.appliedDragOffset;
                final double recede = morphDragRecede(drag.distance);
                final double arm = morphDragArm(flight.dragOffset.distance);
                return Stack(
                  children: <Widget>[
                    // The visual scrim only: taps fall through to the
                    // route's transparent modal barrier, which owns
                    // dismiss behavior and semantics.
                    if (flight.modal)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: ColoredBox(
                            color: flight.scrimColor.withValues(
                              alpha:
                                  flight.scrimColor.a *
                                  flight.scrimOpacity *
                                  morphDragScrimFactor(recede, arm),
                            ),
                          ),
                        ),
                      ),
                    Positioned.fromRect(
                      rect: rect.shift(drag),
                      child: Transform.scale(
                        scale: morphDragScale(recede, arm),
                        child: MediaQuery(
                          data: mediaQuery.copyWith(
                            viewInsets: morphContentViewInsets(
                              overlayViewInsets,
                              rect,
                              overlaySize,
                            ),
                          ),
                          child: child!,
                        ),
                      ),
                    ),
                  ],
                );
              },
              child: Material(
                color: spec.color,
                shape: spec.shape,
                animationDuration: .zero,
                clipBehavior: target.clipBehavior,
                elevation: spec.elevation,
                shadowColor: flight.shadowColor,
                child: measured,
              ),
            );
          },
        );
      },
    );
  }
}

/// Claims the system back gesture at the binding level and forwards it
/// to the route's PredictiveBackRoute hooks. MorphPageRoute is a
/// PopupRoute, so the material page-transitions detector never wraps
/// it - without this bridge nobody would deliver the events. The claim
/// checks mirror the route hook's own guards, because a false return
/// must leave the gesture to other observers (or to the plain pop).
class _RouteBackGestureObserver with WidgetsBindingObserver {
  _RouteBackGestureObserver(this.route);

  final MorphPageRoute<Object?> route;

  @override
  bool handleStartBackGesture(PredictiveBackEvent backEvent) {
    final MorphFlight? flight = route._flight;
    if (!route.isCurrent ||
        route.willHandlePopInternally ||
        flight == null ||
        flight.isFinished) {
      return false;
    }
    route.handleStartBackGesture(progress: backEvent.progress);
    return route._predictiveBack;
  }

  @override
  void handleUpdateBackGestureProgress(PredictiveBackEvent backEvent) =>
      route.handleUpdateBackGestureProgress(progress: backEvent.progress);

  @override
  void handleCommitBackGesture() => route.handleCommitBackGesture();

  @override
  void handleCancelBackGesture() => route.handleCancelBackGesture();
}
