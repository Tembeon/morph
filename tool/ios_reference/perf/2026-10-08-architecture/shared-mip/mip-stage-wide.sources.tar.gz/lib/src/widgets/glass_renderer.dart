import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:morph/src/widgets/glass.dart';
import 'package:morph/src/widgets/glass_channel.dart';
import 'package:morph/src/widgets/glass_container.dart';
import 'package:morph/src/glass/renderer/internal/glass_defaults.dart';
import 'package:morph/src/widgets/glass_liquid.dart';
import 'package:morph/src/widgets/glass_outline.dart';

/// The quality tiers of [MorphGlassRenderer], cheapest first.
///
/// Every tier draws the same shapes: the package computes each surface's
/// outline, the fused silhouettes of a menu and its button or of a bar's
/// capsules, the lens deformation and the content placement once, and a
/// tier only decides how the outline is shaded. A device whose GPU cannot
/// hold liquid glass draws a cheaper tier ([MorphAdaptiveGlass]) and the
/// controls keep their geometry, their motion and their fusion.
enum MorphGlassTier {
  /// A flat fill of each outline in the surface's color, no backdrop
  /// sampling: the cheapest tier, for weak devices.
  flat,

  /// Fake glass: the liquid material without refraction. The backdrop is
  /// frosted and color-filtered as the liquid tier's face transfer does,
  /// and each surface's rim, bevel and highlight are drawn analytically
  /// along its shape; a fused body is clipped to its outline, each region
  /// faced by its largest surface. No lens optics (magnification and
  /// backdrop shrink), no Flutter GPU, so it runs wherever Flutter runs,
  /// the web included.
  fake,

  /// Liquid glass: refraction at the rim, magnification and the measured
  /// lens optics, frost and rim light, rendered on the GPU by the package's
  /// glass renderer. Needs Impeller with Flutter GPU (iOS, macOS,
  /// Android); elsewhere the renderer draws [fake] in its place.
  liquid,
}

/// The iOS 27 glass materials the liquid tier is fitted to.
enum MorphGlassMaterial {
  /// The regular material of `.glass` buttons and controls.
  regular,

  /// The toolbar material, with a stronger rim in dark mode.
  toolbar,

  /// The clear material: no wash, the full bevel on every shape.
  clear,
}

/// The package's glass renderer: draws the surfaces of every measured
/// control at a quality [tier].
///
/// Install it with [MorphGlass], or with [MorphAdaptiveGlass], which picks
/// the tier once by the device's GPU. Only surfaces that are glass in iOS
/// 27 become glass: a plain surface
/// ([MorphGlassSurface.glass] false - the segmented, switch and slider
/// tracks, the stepper) is a flat fill on every tier.
///
/// The shapes are the package's, never the renderer's: a menu fused to its
/// button hands its silhouette as a [MorphGlassOutline], and the surfaces
/// of a glass container (a bar's capsules, [MorphGlassPainter.buildLayer]'s
/// `spacing`) are fused by the skin's merge law before any tier shades
/// them. The liquid tier shades a fused outline from its distance field,
/// so the neck between a menu and its button is liquid glass too.
///
/// On the liquid tier a control's glass body surfaces (bar, button, menu)
/// share a layer and a resting lens, knob or thumb is an opaque platter
/// under the control's content; lifted, it turns into clear glass in a
/// layer of its own above everything of the control, so it refracts what
/// lies under it - the bar's glass included. Lifted, a tab bar lens, a
/// segmented lens and a switch knob minify what lies beneath them and a
/// tab bar lens shows its items magnified, by the amounts measured on the
/// iPhone 16 Pro ([tabBarMagnification], [segmentedShrink] and their
/// kin). Frost is the dearest part of the liquid tier, so only bars,
/// menus and lifted lenses frost unless [frostControls] is on.
///
/// Enable Flutter GPU with `FLTEnableFlutterGPU` in the Apple app's
/// Info.plist or `io.flutter.embedding.android.EnableFlutterGPU` in the
/// Android manifest, and use Impeller. Call [precache] before installing
/// a fixed renderer; [MorphAdaptiveGlass] follows initialization itself.
/// Until shaders are ready, or if they fail, liquid draws fake glass and
/// reports [MorphGlassTier.fake]. An initialization failure is reported
/// once per isolate through [FlutterError.reportError] in every build mode,
/// with library `morph glass`; [liquidUnavailableReason] exposes its reason.
/// Native builds must package the GPU shader bundle from the package's
/// build hook in `build/shaderbundles/`.
/// Wrap a fixed renderer's controls in [BackdropGroup] to share backdrop
/// copies; a section painted over earlier glass and content needs a group
/// of its own (see [MorphAdaptiveGlass]). Wrap a row or cluster of glass
/// buttons in a [MorphGlassContainer] to shade their resting glass in one
/// layer.
@immutable
class MorphGlassRenderer extends MorphGlassPainter {
  /// Creates a renderer at [tier] with the liquid tier's settings.
  const MorphGlassRenderer({
    this.tier = MorphGlassTier.liquid,
    this.material = MorphGlassMaterial.regular,
    this.blur = 1,
    this.refraction = 1,
    this.light = 1,
    this.tint = 0,
    this.frostControls = false,
  });

  /// The quality tier asked for; see [effectiveTier] for the one drawn.
  final MorphGlassTier tier;

  /// The material preset of the liquid tier.
  final MorphGlassMaterial material;

  /// The factor on the preset's frost.
  final double blur;

  /// The factor on the preset's refraction.
  final double refraction;

  /// The factor on the preset's rim glint.
  final double light;

  /// The Liquid Glass slider of iOS Settings, 0 clear and 1 tinted.
  final double tint;

  /// Whether tracks and buttons frost what is behind them as bars and
  /// menus do, on the liquid tier.
  ///
  /// Off by default: a frosted surface blurs its backdrop again on every
  /// frame anything on screen moves, which costs about a millisecond of
  /// raster per surface on an iPhone 16 Pro, and at control size over a
  /// plain page the frost is rarely visible.
  final bool frostControls;

  /// Whether the runtime GPU context and liquid shaders are ready.
  ///
  /// False on the web, whose shader compiler cannot build the renderer's
  /// shaders; there [MorphGlassTier.liquid] draws [MorphGlassTier.fake].
  static bool get liquidAvailable => morphLiquidGlassAvailable;

  /// The reason liquid glass initialization failed on this runtime.
  ///
  /// Null until initialization fails, including while it is pending and
  /// after it succeeds. Await [precache] before reading a resolved result.
  /// Failures are cached for the isolate, shared by all renderer instances,
  /// and reported once through [FlutterError.reportError] in every build
  /// mode. The web reports that it has no liquid glass tier.
  static String? get liquidUnavailableReason =>
      morphLiquidGlassUnavailableReason;

  /// The best tier currently available on this runtime.
  static MorphGlassTier get bestTier =>
      liquidAvailable ? MorphGlassTier.liquid : MorphGlassTier.fake;

  /// The tier this renderer draws: [tier], or [bestTier] when the build
  /// cannot draw [tier].
  MorphGlassTier get effectiveTier =>
      tier == MorphGlassTier.liquid ? bestTier : tier;

  /// Loads the liquid tier's shaders and draws every glass pipeline once
  /// offscreen, so the first glass on screen is already the real one and
  /// compiles nothing.
  ///
  /// Await it before `runApp`: the warm-up takes about 0.35 to 0.45 s on a
  /// Pixel 6a (Vulkan) and moves that cost from the first glass frame to
  /// the launch. It holds the launch for at most one second; a GPU that is
  /// slower to start finishes the warm-up in the background, and glass
  /// drawn before the liquid tier is ready is fake glass.
  ///
  /// Unsupported runtimes and shader loading failures complete normally,
  /// report once through [FlutterError.reportError], and expose the cause
  /// through [liquidUnavailableReason].
  /// On Android, calling before `runApp` can wait for the engine's GPU
  /// context initialization; it does not wait for an application frame.
  static Future<void> precache() => morphPrecacheLiquidGlass();

  /// The same renderer at [tier], or with any other setting replaced.
  MorphGlassRenderer copyWith({
    MorphGlassTier? tier,
    MorphGlassMaterial? material,
    double? blur,
    double? refraction,
    double? light,
    double? tint,
    bool? frostControls,
  }) => MorphGlassRenderer(
    tier: tier ?? this.tier,
    material: material ?? this.material,
    blur: blur ?? this.blur,
    refraction: refraction ?? this.refraction,
    light: light ?? this.light,
    tint: tint ?? this.tint,
    frostControls: frostControls ?? this.frostControls,
  );

  /// The growth of the tab bar items seen through a fully lifted lens.
  ///
  /// Measured on the iPhone 16 Pro tab bar references: the held item's
  /// icon and label show at 1.218 of their resting size while the
  /// swelling bar carries its other items at 1.052, so the lens adds
  /// 1.158 on top of the bar.
  static const double tabBarMagnification = 0.16;

  /// The growth of the segment labels seen through a fully lifted lens.
  ///
  /// None: the iPhone 16 Pro reference (`segmented-held-selected`) shows
  /// the held label at 0.996 of its resting size, in place.
  static const double segmentedMagnification = 0;

  /// The liquid tier's refraction per pixel of UIKit lens displacement.
  ///
  /// A lifted lens bends by `9 * 2 = 18`, under the bevel height of 20, so
  /// its rim compresses what lies just outside it - the edge of the bar
  /// or track it floats over - as UIKit's lens does, instead of mirroring
  /// the content inside it as the 60 of a glass button would.
  static const double lensRefraction = 2;

  /// The color separation along a lifted lens's rim.
  static const double lensDispersion = -0.25;

  /// How much smaller a fully lifted tab bar lens shows the bar glass.
  ///
  /// UIKit's lens minifies the glass beneath it and magnifies only the
  /// items: the iPhone 16 Pro reference (`tabbar3-held-other`) shows the
  /// swollen bar's edges 0.890 of its height apart inside the lens. The
  /// lens's own bevel pulls the backdrop inward near the rim, so it takes
  /// this shrink to put them there.
  static const double tabBarShrink = 0.16;

  /// How much smaller a fully lifted segmented lens shows the track.
  ///
  /// The reference (`segmented-held-selected`) shows the track's edges
  /// 0.8125 of its height apart inside the lens, and the track's end at
  /// 0.964 of its distance from the lens center: the shrink is about the
  /// lens's center line ([lensShrinkRim]), not its center.
  static const double segmentedShrink = 0.20;

  /// How much smaller a fully lifted switch knob shows the track.
  ///
  /// The reference (`switch-off-knob-held`) shows the track's edges 0.755
  /// of its height apart inside the knob. A slider thumb shows its track
  /// unchanged (`slider-thumb-held`), so a thumb does not shrink.
  static const double switchKnobShrink = 0.25;

  /// How far a lifted segmented lens or switch knob shrinks the backdrop
  /// about its center line instead of its center.
  ///
  /// UIKit's lens minifies by depth below its rim: across the straight
  /// part of the capsule and radially about the centers of its round
  /// ends. The references fit the full center line: the track's end
  /// inside a held end segment moves 7 px inward (0.962 of its distance
  /// from the lens center; about the center it moved 36, 0.800), and
  /// inside the switch knob 8 px (15 about the center).
  static const double lensShrinkRim = 1;

  /// The rim weight of a lifted tab bar lens's shrink.
  ///
  /// The swollen bar's end inside a lens held on the end item moves 11 px
  /// inward on the reference (`tabbar3-held-selected`); the full center
  /// line moves it 8 and the center 20, so three quarters of the line.
  static const double tabBarShrinkRim = 0.75;

  /// The lift below which a lens, knob or thumb is only its platter.
  static const double restingLift = 0.005;

  /// The growth of the content, the backdrop shrink and the shrink's rim
  /// weight a fully lifted floating surface of [kind] shows, over a bar
  /// when [overBar].
  ///
  /// A lens over a bar is a tab bar's, a lens over a plain track a
  /// segmented control's, a knob a switch's and a thumb a slider's.
  static ({double magnification, double shrink, double rim}) liftedOptics(
    MorphGlassKind kind, {
    required bool overBar,
  }) => switch (kind) {
    MorphGlassKind.lens =>
      overBar
          ? (
              magnification: tabBarMagnification,
              shrink: tabBarShrink,
              rim: tabBarShrinkRim,
            )
          : (
              magnification: segmentedMagnification,
              shrink: segmentedShrink,
              rim: lensShrinkRim,
            ),
    MorphGlassKind.knob => (
      magnification: 0.0,
      shrink: switchKnobShrink,
      rim: lensShrinkRim,
    ),
    MorphGlassKind.thumb ||
    MorphGlassKind.track ||
    MorphGlassKind.bar ||
    MorphGlassKind.button ||
    MorphGlassKind.menu => (magnification: 0.0, shrink: 0.0, rim: 0.0),
  };

  /// Whether a surface of [kind] floats over its control: a lens, knob or
  /// thumb, an opaque platter at rest and glass only while lifted.
  static bool floats(MorphGlassKind kind) => switch (kind) {
    MorphGlassKind.lens || MorphGlassKind.knob || MorphGlassKind.thumb => true,
    MorphGlassKind.track ||
    MorphGlassKind.bar ||
    MorphGlassKind.button ||
    MorphGlassKind.menu => false,
  };

  /// How far a floating surface has turned from its resting platter into
  /// glass, 0 to 1 over the first quarter of its lift; 1 for every other
  /// surface.
  static double glassness(MorphGlassSurface surface) => floats(surface.kind)
      ? (surface.lift / MorphGlassDefaults.glassLiftSpan).clamp(0.0, 1.0)
      : 1.0;

  bool get _exact => runtimeType == MorphGlassRenderer;

  @override
  Widget buildSurface(BuildContext context, MorphGlassSurface surface) =>
      _surface(
        context,
        MorphGlassFixedSource(MorphGlassFrame([surface])),
        (f) => f.surfaces.single,
      );

  @override
  Widget buildBody(
    BuildContext context,
    MorphGlassOutline outline,
    List<MorphGlassSurface> surfaces,
  ) => _body(
    context,
    MorphGlassFixedSource(MorphGlassFrame(surfaces, outline: outline)),
    (f) => (f.surfaces, f.outline!),
  );

  @override
  Widget buildLayer(
    BuildContext context,
    List<MorphGlassSurface> surfaces, {
    Widget? content,
    List<Rect> contentSlots = const [],
    double spacing = 0,
    MorphGlassOutline? outline,
  }) => _layer(
    context,
    MorphGlassFixedSource(
      MorphGlassFrame(
        surfaces,
        outline: outline,
        contentSlots: contentSlots,
        spacing: spacing,
      ),
    ),
    content: content,
  );

  /// What decides the widget tree of [mode] for [frame]: two frames with
  /// equal structures draw through the same render objects, so the second
  /// is pushed into the tree the first built.
  @internal
  Object structureOf(
    MorphGlassMode mode,
    MorphGlassFrame frame, {
    required bool content,
  }) {
    final tier = effectiveTier;
    return MorphListKey<Object?>(switch (mode) {
      MorphGlassMode.layer => [
        tier,
        content,
        ..._layerStructure(tier, frame.partsFor(tier)),
      ],
      MorphGlassMode.surface => [
        tier,
        ..._surfaceStructure(tier, frame.surfaces.single),
      ],
      MorphGlassMode.fill => const [],
      MorphGlassMode.body => [
        tier,
        ..._bodyStructure(tier, frame.surfaces, frame.outline!),
      ],
    });
  }

  /// Builds the tree of [mode] whose render objects follow [source].
  @internal
  Widget buildFrom(
    BuildContext context,
    MorphGlassMode mode,
    MorphGlassSource source, {
    Widget? content,
  }) => switch (mode) {
    MorphGlassMode.layer => _layer(context, source, content: content),
    MorphGlassMode.surface => _surface(
      context,
      source,
      (f) => f.surfaces.single,
    ),
    MorphGlassMode.fill => liveFill(context, source, (f) => f.surfaces.single),
    MorphGlassMode.body => _body(
      context,
      source,
      (f) => (f.surfaces, f.outline!),
    ),
  };

  static List<Object?> _surfaceStructure(
    MorphGlassTier tier,
    MorphGlassSurface surface,
  ) => [
    surface.kind,
    _visible(surface),
    surface.glass,
    glassness(surface) == 0,
  ];

  static List<Object?> _bodyStructure(
    MorphGlassTier tier,
    List<MorphGlassSurface> surfaces,
    MorphGlassOutline outline,
  ) => [
    surfaces.length,
    for (final s in surfaces) s.kind,
    morphGlassOutlineField(outline) != null,
    morphGlassOutlineShapes(outline) != null,
  ];

  static List<Object?> _layerStructure(
    MorphGlassTier tier,
    MorphGlassLayerParts parts,
  ) => [
    parts.fills.length,
    parts.separate.length,
    for (final s in parts.separate) ..._surfaceStructure(tier, s),
    parts.fused.length,
    for (final (surfaces, outline) in parts.fused)
      ..._bodyStructure(tier, surfaces, outline),
    for (final s in parts.body) s.glow != null,
    parts.floating.length,
    for (final s in parts.floating) ...[
      ..._surfaceStructure(tier, s),
      glassness(s) < 1,
      s.lift > restingLift,
    ],
  ];

  /// The flat fill of the surface [select] picks, following [source]; the
  /// installed painter's own [buildFill] for a subclass.
  @internal
  Widget liveFill(
    BuildContext context,
    MorphGlassSource source,
    MorphGlassSurface Function(MorphGlassFrame frame) select,
  ) => _exact
      ? morphGlassLiveFill(source, select)
      : buildFill(context, select(source.frame));

  /// The glow of the surface [select] picks, following [source]; the
  /// installed painter's own [buildGlow] for a subclass.
  @internal
  Widget liveGlow(
    BuildContext context,
    MorphGlassSource source,
    MorphGlassSurface Function(MorphGlassFrame frame) select,
  ) => _exact
      ? morphGlassLiveGlow(source, select)
      : buildGlow(context, select(source.frame));

  Widget _surface(
    BuildContext context,
    MorphGlassSource source,
    MorphGlassSurface Function(MorphGlassFrame frame) select,
  ) {
    final surface = select(source.frame);
    if (!_visible(surface)) return const SizedBox.expand();
    if (!surface.glass) return liveFill(context, source, select);
    return switch (effectiveTier) {
      MorphGlassTier.flat => liveFill(context, source, select),
      MorphGlassTier.fake || MorphGlassTier.liquid => morphLiquidSurface(
        this,
        context,
        source,
        select,
      ),
    };
  }

  Widget _body(
    BuildContext context,
    MorphGlassSource source,
    (List<MorphGlassSurface>, MorphGlassOutline) Function(MorphGlassFrame f)
    select,
  ) => switch (effectiveTier) {
    MorphGlassTier.flat => morphGlassLiveBody(source, select),
    MorphGlassTier.fake ||
    MorphGlassTier.liquid => morphLiquidBody(this, context, source, select),
  };

  Widget _layer(
    BuildContext context,
    MorphGlassSource source, {
    Widget? content,
  }) {
    if (effectiveTier != MorphGlassTier.flat) {
      return morphLiquidLayer(this, context, source, content: content);
    }
    MorphGlassLayerParts partsOf(MorphGlassFrame f) =>
        _exact ? f.partsFor(MorphGlassTier.flat) : f.parts;
    final parts = partsOf(source.frame);
    Widget at(
      (String, int) slot,
      Rect Function(MorphGlassFrame f) rect,
      Widget Function() child,
    ) => source.keep(
      slot,
      () => MorphLivePositioned(
        key: ValueKey<(String, int)>(slot),
        rect: source.pick(rect),
        child: child(),
      ),
    );
    return MorphLiveStack(
      live: source.live,
      children: [
        for (var i = 0; i < parts.fills.length; i++)
          at(
            ('fill', i),
            (f) => partsOf(f).fills[i].bounds,
            () => liveFill(context, source, (f) => partsOf(f).fills[i]),
          ),
        for (var i = 0; i < parts.separate.length; i++)
          at(
            ('surface', i),
            (f) => partsOf(f).separate[i].bounds,
            () => _exact
                ? _surface(context, source, (f) => partsOf(f).separate[i])
                : buildSurface(context, parts.separate[i]),
          ),
        for (var i = 0; i < parts.fused.length; i++)
          source.keep(
            ('body', i),
            () => Positioned.fill(
              key: ValueKey<(String, int)>(('body', i)),
              child: _exact
                  ? _body(context, source, (f) => partsOf(f).fused[i])
                  : buildBody(context, parts.fused[i].$2, parts.fused[i].$1),
            ),
          ),
        for (final (i, surface) in parts.body.indexed)
          if (surface.glow != null)
            at(
              ('glow', i),
              (f) => partsOf(f).body[i].bounds,
              () => liveGlow(context, source, (f) => partsOf(f).body[i]),
            ),
        for (var i = 0; i < parts.floating.length; i++)
          at(
            ('floating', i),
            (f) => partsOf(f).floating[i].bounds,
            () => _exact
                ? _surface(context, source, (f) => partsOf(f).floating[i])
                : buildSurface(context, parts.floating[i]),
          ),
        if (content != null)
          Positioned.fill(
            key: const ValueKey<String>('content'),
            child: content,
          ),
      ],
    );
  }

  static bool _visible(MorphGlassSurface surface) =>
      surface.bounds.width >= 0.5 && surface.bounds.height >= 0.5;

  @override
  bool operator ==(Object other) =>
      other is MorphGlassRenderer &&
      other.tier == tier &&
      other.material == material &&
      other.blur == blur &&
      other.refraction == refraction &&
      other.light == light &&
      other.tint == tint &&
      other.frostControls == frostControls;

  @override
  int get hashCode =>
      Object.hash(tier, material, blur, refraction, light, tint, frostControls);
}

/// The surfaces of one [MorphGlassPainter.buildLayer] call, sorted by how
/// a tier draws them, with the glass bodies the package fused.
@internal
@immutable
class MorphGlassLayerParts {
  const MorphGlassLayerParts._({
    required this.fills,
    required this.separate,
    required this.fused,
    required this.floating,
  });

  /// Sorts the visible [surfaces] of a layer: plain fills, glass body
  /// surfaces drawn as their own shapes, glass bodies fused into one
  /// outline - the control's [outline], or the groups a glass container
  /// with [spacing] fuses - and floating lenses, knobs and thumbs.
  /// With [withField] false, generated fused bodies carry their silhouette
  /// alone; supplied [outline] values are retained unchanged.
  factory MorphGlassLayerParts.of(
    List<MorphGlassSurface> surfaces, {
    double spacing = 0,
    MorphGlassOutline? outline,
    bool withField = true,
  }) {
    final visible = [
      for (final s in surfaces)
        if (MorphGlassRenderer._visible(s)) s,
    ];
    final body = [
      for (final s in visible)
        if (s.glass && !MorphGlassRenderer.floats(s.kind)) s,
    ];
    final separate = <MorphGlassSurface>[];
    final fused = <(List<MorphGlassSurface>, MorphGlassOutline)>[];
    if (outline != null && body.isNotEmpty) {
      fused.add((body, outline));
    } else {
      for (final group in morphGlassContainerGroups([
        for (final s in body) s.shape,
      ], spacing)) {
        if (group.length == 1) {
          separate.add(body[group.single]);
        } else {
          final members = [for (final i in group) body[i]];
          fused.add((
            members,
            morphGlassContainerOutline(
              [for (final s in members) s.shape],
              spacing,
              withField: withField,
            ),
          ));
        }
      }
    }
    return MorphGlassLayerParts._(
      fills: [
        for (final s in visible)
          if (!s.glass) s,
      ],
      separate: separate,
      fused: fused,
      floating: [
        for (final s in visible)
          if (s.glass && MorphGlassRenderer.floats(s.kind)) s,
      ],
    );
  }

  /// The plain surfaces, drawn flat on every tier.
  final List<MorphGlassSurface> fills;

  /// The glass body surfaces drawn as their own shapes.
  final List<MorphGlassSurface> separate;

  /// The glass bodies fused into one outline each, with their surfaces.
  final List<(List<MorphGlassSurface>, MorphGlassOutline)> fused;

  /// The lenses, knobs and thumbs.
  final List<MorphGlassSurface> floating;

  /// Every glass body surface, separate and fused.
  List<MorphGlassSurface> get body => [
    ...separate,
    for (final (surfaces, _) in fused) ...surfaces,
  ];
}
