import 'dart:convert';
import 'dart:developer' as developer;
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_gpu/gpu.dart' as gpu;
import 'package:morph/widgets.dart' show MorphGlassRenderer;
import 'package:morph_example/perf/glass_stage_bench.dart' show stageBenchStats;

const _width = 1024;
const _height = 2048;
const _sigmaPx = 16.0;
const _levels = 5;
const _runs = int.fromEnvironment('MIP_RUNS', defaultValue: 3);
const _warmMs = int.fromEnvironment('MIP_WARM_MS', defaultValue: 400);
const _sampleMs = int.fromEnvironment('MIP_SAMPLE_MS', defaultValue: 1600);
const _seed = int.fromEnvironment('MIP_SEED', defaultValue: 20261008);
const _shots = bool.fromEnvironment('MIP_SHOTS');

/// Measures shared GPU pyramid production and multiple blur-only consumers.
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const _Bench());
}

class _Case {
  const _Case(this.mode, this.count, this.dynamicSource);
  final String mode;
  final int count;
  final bool dynamicSource;
  String get name => 'mip-$mode-n$count-${dynamicSource ? 'fresh' : 'reuse'}';
  bool get pyramid => mode == 'box' || mode == 'tent';
  double get lod => mode == 'box' ? 4.9526399109241535 : 4.688035443343443;
}

List<_Case> _cases() {
  final modes = const String.fromEnvironment(
    'MIP_MODES',
    defaultValue: 'gaussian,grouped,box,tent,cached,bare',
  ).split(',');
  final counts = const String.fromEnvironment(
    'MIP_COUNTS',
    defaultValue: '1,2,4,8,16',
  ).split(',').map(int.parse).toList();
  final updates = const String.fromEnvironment(
    'MIP_UPDATES',
    defaultValue: 'fresh,reuse',
  ).split(',');
  if (_runs < 1 ||
      _warmMs < 100 ||
      _sampleMs < 100 ||
      modes.any(
        (s) => ![
          'bare',
          'gaussian',
          'grouped',
          'box',
          'tent',
          'cached',
        ].contains(s),
      ) ||
      counts.any((n) => ![1, 2, 4, 8, 16].contains(n)) ||
      updates.any((s) => !['fresh', 'reuse'].contains(s)) ||
      modes.toSet().length != modes.length ||
      counts.toSet().length != counts.length ||
      updates.toSet().length != updates.length) {
    throw ArgumentError('Invalid MIP benchmark selection');
  }
  return [
    for (final mode in modes)
      for (final n in counts)
        for (final update in updates)
          if (mode != 'cached' || update == 'reuse')
            _Case(mode, n, update == 'fresh'),
  ];
}

List<ui.Rect> _rects(int count, ui.Size size) {
  final columns = math.sqrt(count).ceil();
  final rows = (count / columns).ceil();
  final cellW = size.width / columns;
  final cellH = size.height / rows;
  final scale = math.sqrt(.3 * columns * rows / count);
  return [
    for (var i = 0; i < count; i++)
      ui.Rect.fromCenter(
        center: ui.Offset(
          cellW * (i % columns + .5),
          cellH * (i ~/ columns + .5),
        ),
        width: cellW * scale,
        height: cellH * scale,
      ),
  ];
}

class _Kernel {
  _Kernel(gpu.ShaderLibrary library, String name, String block) {
    final vertex = library['MipVertex']!;
    final fragment = library[name]!;
    pipeline = gpu.gpuContext.createRenderPipeline(vertex, fragment);
    uniforms = fragment.getUniformSlot(block);
    sampler = name == 'MipDownsample'
        ? fragment.getUniformSlot('uInput')
        : null;
  }
  late final gpu.RenderPipeline pipeline;
  late final gpu.UniformSlot uniforms;
  late final gpu.UniformSlot? sampler;
}

gpu.BufferView _fixedUniforms(List<double> values) {
  final bytes = ByteData.sublistView(Float32List.fromList(values));
  return gpu.BufferView(
    gpu.gpuContext.createDeviceBufferWithCopy(bytes),
    offsetInBytes: 0,
    lengthInBytes: bytes.lengthInBytes,
  );
}

// This Vulkan-only probe uses the renderer's four-target / three-scene-epoch
// retirement contract, plus producer completion. All writes and Flutter reads
// use the same GPU queue. A target cannot be reused while an older unsubmitted
// scene can still read it. Do not infer cross-backend safety from this probe.
class _Target {
  _Target(int width, int height)
    : texture = gpu.gpuContext.createTexture(
        gpu.StorageMode.devicePrivate,
        width,
        height,
        format: gpu.PixelFormat.r8g8b8a8UNormInt,
      );
  final gpu.Texture texture;
  int lastEpoch = -100;
  bool pending = false;
}

class _TextureRing {
  _TextureRing(this.width, this.height)
    : targets = [for (var i = 0; i < 4; i++) _Target(width, height)];
  final int width;
  final int height;
  final List<_Target> targets;
  _Target? current;
  _Target lease(int epoch) {
    final target = targets.firstWhere(
      (t) => t != current && !t.pending && epoch - t.lastEpoch >= 3,
      orElse: () => throw StateError('No safely retired GPU target'),
    );
    target.lastEpoch = epoch;
    target.pending = true;
    current = target;
    return target;
  }

  int get bytes => width * height * 4 * targets.length;
}

class _Producer {
  _Producer(gpu.ShaderLibrary library)
    : sourceKernel = _Kernel(library, 'MipSource', 'SourceUniforms'),
      mipKernel = _Kernel(library, 'MipDownsample', 'MipUniforms') {
    final bytes = ByteData.sublistView(
      Float32List.fromList([
        -1,
        -1,
        0,
        0,
        1,
        -1,
        1,
        0,
        -1,
        1,
        0,
        1,
        1,
        1,
        1,
        1,
      ]),
    );
    vertices = gpu.BufferView(
      gpu.gpuContext.createDeviceBufferWithCopy(bytes),
      offsetInBytes: 0,
      lengthInBytes: bytes.lengthInBytes,
    );
    for (final kind in ['box', 'tent']) {
      rings[kind] = [
        for (var l = 1; l <= _levels; l++)
          _TextureRing(_width >> l, _height >> l),
      ];
      mipUniforms[kind] = [
        for (var l = 1; l <= _levels; l++)
          _fixedUniforms([
            (_width >> (l - 1)).toDouble(),
            (_height >> (l - 1)).toDouble(),
            kind == 'tent' ? 1 : 0,
            0,
          ]),
      ];
    }
  }
  final _Kernel sourceKernel;
  final _Kernel mipKernel;
  late final gpu.BufferView vertices;
  final base = _TextureRing(_width, _height);
  final rings = <String, List<_TextureRing>>{};
  final mipUniforms = <String, List<gpu.BufferView>>{};
  final images = <String, List<ui.Image>>{};
  final revisions = <String, int>{};
  final availableUniforms = <gpu.DeviceBuffer>[];
  final stopwatch = Stopwatch();
  ui.Image? source;
  ui.Image? cachedGaussian;
  int cachedGaussianWaitUs = 0;
  double? previousPhase;
  int revision = 0;
  int sourcePasses = 0;
  int mipPasses = 0;
  int uniformAllocations = 0;
  int recordUs = 0;
  int paintCalls = 0;
  int epoch = 0;
  Duration? previousFrame;
  String? failure;
  bool disposed = false;

  void check() {
    if (failure case final message?) throw StateError(message);
  }

  gpu.Texture _draw(
    _TextureRing ring,
    _Kernel kernel,
    gpu.BufferView uniforms, {
    gpu.Texture? input,
    gpu.DeviceBuffer? leased,
  }) {
    final target = ring.lease(epoch);
    final command = gpu.gpuContext.createCommandBuffer();
    try {
      final pass = command.createRenderPass(
        gpu.RenderTarget.singleColor(
          gpu.ColorAttachment(
            texture: target.texture,
            loadAction: gpu.LoadAction.dontCare,
          ),
        ),
      );
      pass.bindPipeline(kernel.pipeline);
      pass.bindVertexBuffer(vertices);
      pass.setPrimitiveType(gpu.PrimitiveType.triangleStrip);
      pass.bindUniform(kernel.uniforms, uniforms);
      if (input != null) {
        pass.bindTexture(
          kernel.sampler!,
          input,
          sampler: gpu.SamplerOptions(
            minFilter: gpu.MinMagFilter.linear,
            magFilter: gpu.MinMagFilter.linear,
          ),
        );
      }
      pass.draw(4);
      command.submit(
        completionCallback: (success) {
          target.pending = false;
          if (!success) failure = 'GPU producer command failed';
          if (leased != null && !disposed) availableUniforms.add(leased);
        },
      );
      return target.texture;
    } on Object {
      target.pending = false;
      rethrow;
    }
  }

  void update(_Case c, double phase) {
    check();
    stopwatch.reset();
    stopwatch.start();
    paintCalls++;
    final stamp = SchedulerBinding.instance.currentFrameTimeStamp;
    if (stamp != previousFrame) {
      epoch++;
      previousFrame = stamp;
    }
    final nextPhase = c.dynamicSource ? phase : 0.0;
    if (source == null || nextPhase != previousPhase) {
      final allocate = availableUniforms.isEmpty;
      if (allocate) uniformAllocations++;
      final buffer = allocate
          ? gpu.gpuContext.createDeviceBuffer(gpu.StorageMode.hostVisible, 16)
          : availableUniforms.removeLast();
      final data = ByteData.sublistView(
        Float32List.fromList([
          _width.toDouble(),
          _height.toDouble(),
          nextPhase * 80,
          0,
        ]),
      );
      if (!buffer.overwrite(data)) throw StateError('Uniform write failed');
      _draw(
        base,
        sourceKernel,
        gpu.BufferView(buffer, offsetInBytes: 0, lengthInBytes: 16),
        leased: buffer,
      );
      source?.dispose();
      source = base.current!.texture.asImage();
      previousPhase = nextPhase;
      revision++;
      sourcePasses++;
    }
    if (c.pyramid && revisions[c.mode] != revision) {
      var input = base.current!.texture;
      final nextImages = <ui.Image>[];
      try {
        for (var i = 0; i < _levels; i++) {
          input = _draw(
            rings[c.mode]![i],
            mipKernel,
            mipUniforms[c.mode]![i],
            input: input,
          );
          final image = input.asImage();
          nextImages.add(image);
          mipPasses++;
        }
      } on Object {
        for (final image in nextImages) {
          image.dispose();
        }
        rethrow;
      }
      for (final image in images[c.mode] ?? <ui.Image>[]) {
        image.dispose();
      }
      images[c.mode] = nextImages;
      revisions[c.mode] = revision;
    }
    stopwatch.stop();
    recordUs += stopwatch.elapsedMicroseconds;
  }

  Future<void> prepareCachedGaussian() async {
    if (cachedGaussian != null) return;
    if (previousPhase != 0 || source == null) {
      throw StateError('Cache input must be the canonical static source');
    }
    final elapsed = Stopwatch();
    elapsed.start();
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder);
    const rect = ui.Rect.fromLTWH(0, 0, 1024, 2048);
    final filterPaint = ui.Paint();
    filterPaint.imageFilter = ui.ImageFilter.blur(
      sigmaX: _sigmaPx,
      sigmaY: _sigmaPx,
    );
    canvas.saveLayer(rect, filterPaint);
    canvas.drawImage(source!, ui.Offset.zero, ui.Paint());
    canvas.restore();
    final picture = recorder.endRecording();
    try {
      cachedGaussian = await picture.toImage(_width, _height);
    } finally {
      picture.dispose();
    }
    elapsed.stop();
    cachedGaussianWaitUs = elapsed.elapsedMicroseconds;
  }

  int get ownedBytes =>
      (cachedGaussian == null ? 0 : _width * _height * 4) +
      base.bytes +
      rings.values.expand((s) => s).fold(0, (int a, s) => a + s.bytes);

  Map<String, int> get counters => {
    'source_passes': sourcePasses,
    'downsample_passes': mipPasses,
    'producer_submissions': sourcePasses + mipPasses,
    'producer_record_us': recordUs,
    'producer_paints': paintCalls,
    'uniform_allocations': uniformAllocations,
    'surface_retained_bytes': ownedBytes,
    'surface_peak_bytes': ownedBytes,
  };

  void dispose() {
    disposed = true;
    source?.dispose();
    cachedGaussian?.dispose();
    for (final image in images.values.expand((s) => s)) {
      image.dispose();
    }
    images.clear();
    availableUniforms.clear();
  }
}

class _SourcePainter extends CustomPainter {
  _SourcePainter(this.producer, this.c, this.phase) : super(repaint: phase);
  final _Producer producer;
  final _Case c;
  final ValueNotifier<double> phase;
  @override
  void paint(ui.Canvas canvas, ui.Size size) {
    producer.update(c, phase.value);
    final paint = ui.Paint();
    paint.filterQuality = ui.FilterQuality.low;
    canvas.drawImageRect(
      producer.source!,
      ui.Rect.fromLTWH(0, 0, _width.toDouble(), _height.toDouble()),
      ui.Offset.zero & size,
      paint,
    );
  }

  @override
  bool shouldRepaint(_SourcePainter old) => old.c != c;
}

class _MipPainter extends CustomPainter {
  _MipPainter(this.producer, this.c, this.phase, this.shader, this.dpr)
    : super(repaint: phase);
  final _Producer producer;
  final _Case c;
  final ValueNotifier<double> phase;
  final ui.FragmentShader shader;
  final double dpr;
  @override
  void paint(ui.Canvas canvas, ui.Size size) {
    final levels = producer.images[c.mode]!;
    final lower = c.lod.floor();
    shader.setFloat(0, size.width);
    shader.setFloat(1, size.height);
    shader.setFloat(2, c.lod - lower);
    shader.setImageSampler(
      0,
      levels[lower - 1],
      filterQuality: ui.FilterQuality.low,
    );
    shader.setImageSampler(
      1,
      levels[lower],
      filterQuality: ui.FilterQuality.low,
    );
    final paint = ui.Paint();
    paint.shader = shader;
    for (final rect in _rects(c.count, size)) {
      canvas.save();
      canvas.clipRRect(
        ui.RRect.fromRectAndRadius(
          rect.shift(ui.Offset(phase.value * 12 / dpr, 0)),
          ui.Radius.circular(12 / dpr),
        ),
      );
      canvas.drawRect(ui.Offset.zero & size, paint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_MipPainter old) => old.c != c;
}

class _CachedPainter extends CustomPainter {
  _CachedPainter(this.producer, this.c, this.phase, this.dpr)
    : super(repaint: phase);
  final _Producer producer;
  final _Case c;
  final ValueNotifier<double> phase;
  final double dpr;
  @override
  void paint(ui.Canvas canvas, ui.Size size) {
    final image = producer.cachedGaussian;
    if (image == null) return;
    final paint = ui.Paint();
    paint.filterQuality = ui.FilterQuality.low;
    for (final rect in _rects(c.count, size)) {
      canvas.save();
      canvas.clipRRect(
        ui.RRect.fromRectAndRadius(
          rect.shift(ui.Offset(phase.value * 12 / dpr, 0)),
          ui.Radius.circular(12 / dpr),
        ),
      );
      canvas.drawImageRect(
        image,
        ui.Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
        ui.Offset.zero & size,
        paint,
      );
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_CachedPainter old) => old.c != c;
}

class _Bench extends StatefulWidget {
  const _Bench();
  @override
  State<_Bench> createState() => _BenchState();
}

class _BenchState extends State<_Bench> with SingleTickerProviderStateMixin {
  final phase = ValueNotifier<double>(0);
  final timings = <ui.FrameTiming>[];
  final windows = <String, List<List<int>>>{};
  final work = <String, List<Map<String, int>>>{};
  final metadata = <String, Map<String, Object>>{};
  final order = <String>[];
  final key = GlobalKey();
  late final Ticker ticker;
  _Producer? producer;
  ui.FragmentShader? shader;
  _Case? current;

  @override
  void initState() {
    super.initState();
    ticker = createTicker(
      (time) =>
          phase.value = math.sin(time.inMicroseconds * 2 * math.pi / 2000000),
    );
    SchedulerBinding.instance.addTimingsCallback(collect);
    WidgetsBinding.instance.addPostFrameCallback((_) => run());
  }

  void collect(List<ui.FrameTiming> batch) => timings.addAll(batch);
  @override
  void dispose() {
    ticker.dispose();
    phase.dispose();
    shader?.dispose();
    producer?.dispose();
    SchedulerBinding.instance.removeTimingsCallback(collect);
    super.dispose();
  }

  Future<void> mount(_Case c) async {
    ticker.stop();
    phase.value = 0;
    setState(() => current = c);
    await SchedulerBinding.instance.endOfFrame;
    if (c.mode == 'cached') {
      await producer!.prepareCachedGaussian();
    }
    ticker.start();
    await Future<void>.delayed(const Duration(milliseconds: _warmMs));
  }

  Future<void> run() async {
    final out = Directory(
      const String.fromEnvironment(
        'AUDIT_OUT',
        defaultValue: '/tmp/morph-mip-stage',
      ),
    );
    try {
      if (kDebugMode) throw StateError('Native stage bench requires AOT');
      final cases = _cases();
      await MorphGlassRenderer.precache();
      if (!MorphGlassRenderer.liquidAvailable) {
        throw StateError('Native GPU unavailable');
      }
      final library = await gpu.ShaderLibrary.fromAsset(
        'perf_assets/mip.shaderbundle',
      );
      if (library == null) throw StateError('Missing mip bundle');
      producer = _Producer(library);
      shader = (await ui.FragmentProgram.fromAsset(
        'lib/perf/shaders/mip_consumer.frag',
      )).fragmentShader();
      for (final c in cases) {
        await mount(c);
      }
      final random = math.Random(_seed);
      for (var repeat = 0; repeat < _runs; repeat++) {
        final shuffled = [...cases];
        shuffled.shuffle(random);
        for (final c in shuffled) {
          await mount(c);
          final start = developer.Timeline.now;
          final before = producer!.counters;
          developer.Timeline.startSync('scene:${c.name}:$repeat:begin');
          developer.Timeline.finishSync();
          await Future<void>.delayed(const Duration(milliseconds: _sampleMs));
          final end = developer.Timeline.now;
          developer.Timeline.startSync('scene:${c.name}:$repeat:end');
          developer.Timeline.finishSync();
          final after = producer!.counters;
          (windows[c.name] ??= []).add([start, end]);
          (work[c.name] ??= []).add({
            for (final k in before.keys)
              k: k.startsWith('surface_') ? after[k]! : after[k]! - before[k]!,
          });
          order.add(c.name);
          metadata[c.name] = {
            'layout': 'owned-texture-n${c.count}',
            'motion': c.dynamicSource ? 'background-and-glass' : 'glass',
            'plan': c.mode == 'gaussian' ? 'independent' : 'shared',
            'mode': c.mode,
            'lens_count': c.count,
            'requested_sigma_physical': _sigmaPx,
            'source_update': c.dynamicSource ? 'every-frame' : 'unchanged',
            'lod': c.pyramid ? c.lod : 0.0,
            'visible_rects_logical': [
              for (final r in _rects(
                c.count,
                ui.Size(
                  _width /
                      ui
                          .PlatformDispatcher
                          .instance
                          .views
                          .first
                          .devicePixelRatio,
                  _height /
                      ui
                          .PlatformDispatcher
                          .instance
                          .views
                          .first
                          .devicePixelRatio,
                ),
              ))
                [r.left, r.top, r.width, r.height],
            ],
          };
        }
      }
      ticker.stop();
      await Future<void>.delayed(const Duration(milliseconds: 1200));
      producer!.check();
      out.createSync(recursive: true);
      final report = makeReport();
      if (_shots) {
        for (final c in cases) {
          await mount(c);
          ticker.stop();
          phase.value = 0;
          await SchedulerBinding.instance.endOfFrame;
          await SchedulerBinding.instance.endOfFrame;
          final boundary =
              key.currentContext!.findRenderObject()! as RenderRepaintBoundary;
          final image = await boundary.toImage(
            pixelRatio:
                ui.PlatformDispatcher.instance.views.first.devicePixelRatio,
          );
          try {
            final png = await image.toByteData(format: ui.ImageByteFormat.png);
            if (png == null) throw StateError('Missing phase PNG');
            File('${out.path}/${c.name}.png').writeAsBytesSync(
              png.buffer.asUint8List(png.offsetInBytes, png.lengthInBytes),
            );
          } finally {
            image.dispose();
          }
        }
      }
      ticker.stop();
      final temporary = File('${out.path}/report.tmp');
      temporary.writeAsStringSync(jsonEncode(report));
      temporary.renameSync('${out.path}/report.json');
    } on Object catch (error, stack) {
      ticker.stop();
      out.createSync(recursive: true);
      File(
        '${out.path}/error.json',
      ).writeAsStringSync(jsonEncode({'error': '$error', 'stack': '$stack'}));
    }
  }

  Map<String, Object> makeReport() {
    final view = View.of(context);
    final budget = 1000 / view.display.refreshRate;
    return {
      'schema': 'morph-stage-bench-v1',
      'fixture': 'shared-mip-owned-texture-blur-only',
      'resource_pool':
          'four targets / three scene epochs / producer completion, Vulkan only',
      'platform': Platform.operatingSystem,
      'build_mode': kProfileMode ? 'profile' : 'release',
      'refresh_rate': view.display.refreshRate,
      'budget_ms': budget,
      'device_pixel_ratio': view.devicePixelRatio,
      'physical_size': [_width, _height],
      'liquid_available': MorphGlassRenderer.liquidAvailable,
      'runs': _runs,
      'warm_ms': _warmMs,
      'sample_ms': _sampleMs,
      'seed': _seed,
      'order': order,
      'case_metadata': metadata,
      'cached_gaussian_initial_wait_us': producer!.cachedGaussianWaitUs,
      'windows_us': windows,
      'window_work': work,
      'limitations': [
        'Owned synthetic GPU source; no live Flutter backdrop acquisition or final glass optics.',
        'Pyramid LOD fitted to numerical average PSF; native Gaussian equivalence is not assumed.',
        'Surface byte counters are fixed texture rings, including both kernel families; exclude native filter intermediates.',
        'CPU recording and active GPU work are not presentation latency.',
      ],
      for (final entry in windows.entries)
        entry.key: {
          'runs': [
            for (final window in entry.value)
              () {
                final frames = timings.where((f) {
                  final t = f.timestampInMicroseconds(ui.FramePhase.vsyncStart);
                  return t >= window[0] && t < window[1];
                }).toList();
                if (frames.length < 4) {
                  throw StateError('Missing timing frames');
                }
                return {
                  ...stageBenchStats(frames, budget),
                  'frames': [
                    for (final f in frames)
                      [
                        f.timestampInMicroseconds(ui.FramePhase.vsyncStart),
                        f.buildDuration.inMicroseconds,
                        f.rasterDuration.inMicroseconds,
                        f.totalSpan.inMicroseconds,
                      ],
                  ],
                };
              }(),
          ],
        },
    };
  }

  @override
  Widget build(BuildContext context) {
    final dpr = ui.PlatformDispatcher.instance.views.first.devicePixelRatio;
    final size = ui.Size(_width / dpr, _height / dpr);
    final c = current;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: ColoredBox(
        color: const ui.Color(0xFF000000),
        child: Center(
          child: RepaintBoundary(
            key: key,
            child: SizedBox.fromSize(
              size: size,
              child: c == null
                  ? const SizedBox.shrink()
                  : Stack(
                      children: [
                        Positioned.fill(
                          child: CustomPaint(
                            painter: _SourcePainter(producer!, c, phase),
                          ),
                        ),
                        if (c.pyramid)
                          Positioned.fill(
                            child: CustomPaint(
                              painter: _MipPainter(
                                producer!,
                                c,
                                phase,
                                shader!,
                                dpr,
                              ),
                            ),
                          )
                        else if (c.mode == 'cached')
                          Positioned.fill(
                            child: CustomPaint(
                              painter: _CachedPainter(producer!, c, phase, dpr),
                            ),
                          )
                        else if (c.mode != 'bare')
                          AnimatedBuilder(
                            animation: phase,
                            child: Stack(
                              children: [
                                for (final r in _rects(c.count, size))
                                  Positioned.fromRect(
                                    rect: r,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(
                                        12 / dpr,
                                      ),
                                      child: BackdropFilter(
                                        backdropGroupKey: c.mode == 'grouped'
                                            ? _sharedKey
                                            : null,
                                        filter: ui.ImageFilter.blur(
                                          sigmaX: _sigmaPx / dpr,
                                          sigmaY: _sigmaPx / dpr,
                                        ),
                                        child: const SizedBox.expand(),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                            builder: (context, child) => Transform.translate(
                              offset: ui.Offset(phase.value * 12 / dpr, 0),
                              child: child,
                            ),
                          ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }

  final _sharedKey = BackdropKey();
}
